CodeRunner uses the /classes directory by default when it looks for any custom code.
You can copy your compiled .class files into this directory so it is automatically recognized by CodeRunner.
Make sure to keep the directory structure matching the namespaces of your code.
For example if the code is in the com.foo.bar namespace, the classes in the namespace must be located in the /classes/com/foo/bar directory.