
package com.sharehome;

import com.backendless.Backendless;
import com.backendless.servercode.IBackendlessBootstrap;


public class Bootstrap implements IBackendlessBootstrap
{
            
  @Override
  public void onStart()
  {

    // add your code here
  }
    
  @Override
  public void onStop()
  {
    // add your code here
  }
    
}
        