/** Automatically generated file. DO NOT MODIFY */
package com.backendless.examples.geoservice.geodemo;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}