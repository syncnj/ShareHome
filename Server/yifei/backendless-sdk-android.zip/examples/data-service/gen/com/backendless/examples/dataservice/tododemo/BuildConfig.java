/** Automatically generated file. DO NOT MODIFY */
package com.backendless.examples.dataservice.tododemo;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}