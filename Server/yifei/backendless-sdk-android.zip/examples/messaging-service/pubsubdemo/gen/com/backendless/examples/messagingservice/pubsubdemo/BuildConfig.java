/** Automatically generated file. DO NOT MODIFY */
package com.backendless.examples.messagingservice.pubsubdemo;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}